<?php

// sitio de la base de datos (mysql:host=) i nombre de la base de datos que estamos utilizando (dbname=)
const constDSN = "mysql:host=localhost;dbname=mascotasclinic";

// nombre de el usuario de la base de datos
const constUSUARIO = "m07";

// password de el usuario de la base de datos
const  constPASSWORD = "m07";
