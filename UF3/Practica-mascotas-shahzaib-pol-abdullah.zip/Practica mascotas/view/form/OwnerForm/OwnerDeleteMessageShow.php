<div id="content">
    <h1>
        Deleted Successfully
    </h1>
</div>