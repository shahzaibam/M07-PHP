<div id="content">
        <?php
         echo '<div style="display: flex; flex-wrap: wrap;">';
            // mostramos la IMG1
            echo "<div>";
            echo '<a href=""><img src="view/img/1.jpg">';
            echo "<br>";
            echo '<a href="view\options\Books\Books.php">Books</a>';
            echo "</div>";

            // mostramos la IMG2
            echo "<div>";
            echo '<a href=""><img src="view/img/2.jpg">';
            echo "<br>";
            echo '<a href="">News</a>';
            echo "</div>";

            // mostramos la IMG3
            echo "<div>";
            echo '<a href=""><img src="view/img/3.jpg">';
            echo "<br>";
            echo '<a href="">Webs</a>';
            echo "</div>";

            echo "<div>";
        ?>
</div>
