<?php

namespace App\Http\Controllers;

use App\Models\Evento;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EventsController extends Controller
{
    public function index() {
        return view("events.index");
    }


    /**
     * @param Request $request --> todos los datos introducidos en el form los validamos
     * @return \Illuminate\Http\RedirectResponse
     *
     * funcion que valida los campos del form y crea un evento, y asign el id del user activo al evento que se esta creando
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'fecha' => 'required|date',
            'hora' => 'required',
        ]);

        $validatedData['user_id'] = Auth::id();

        $evento = Evento::create($validatedData);

        return redirect()->route('home')->with('status', 'Evento creado con éxito.');
    }


    public function edit($id)
    {
        $evento = Evento::findOrFail($id);

        if (Auth::id() !== $evento->user_id) {
            return redirect()->route('events.index')->with('error', 'No tienes permiso para editar este evento.');
        }

        return view('events.edit', compact('evento'));
    }



    public function update(Request $request, Evento $evento) // La inyección de modelo aquí captura el 'event' de la ruta
    {

        $user_id = $evento->user_id;


        dd($user_id);


        // Añade aquí la verificación de propiedad si es necesario
        if (Auth::id() !== $evento->user_id) {
            return redirect()->route('home')->with('error', 'No tienes permiso para actualizar este evento.');
        }

        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'fecha' => 'required|date',
            'hora' => 'required',
        ]);


        $evento->update($validatedData);

        return redirect()->route('home')->with('status', 'Evento actualizado con éxito.');
    }



}
