<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\M07-PHP\UF3\Laravel_v10\projectUPC\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>