<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Street Racers</title>
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <link href="<?php echo e(asset('css/home/styles.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-4.0.0-dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
</head>
<body>

<header>
    <!-- Aquí se incluiría la barra de navegación, asegurándose de que es responsiva -->
    <?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>

<div class="hero">
    <div class="container text-center" style="margin-top: 700px;">
        <h1 id="title"></h1>
    </div>
</div>

<div class="content">
    <div>
        <?php echo $__env->make("layouts.serviceCards", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    </div>
</div>

<script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('css/bootstrap-4.0.0-dist/js/bootstrap.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        var text = "Keep pushing, the stars are within reach...";
        var i = 0;
        var speed = 100; // Velocidad en milisegundos

        function typeWriter() {
            console.log('Executing typeWriter', i);
            if (i < text.length) {
                $('#title').html($('#title').html() + text.charAt(i));
                i++;
                setTimeout(typeWriter, speed);
            }
        }


        typeWriter(); // Iniciar la animación
    });
</script>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\M07-PHP\UF3\Laravel_v10\projectUPC\resources\views/welcome.blade.php ENDPATH**/ ?>