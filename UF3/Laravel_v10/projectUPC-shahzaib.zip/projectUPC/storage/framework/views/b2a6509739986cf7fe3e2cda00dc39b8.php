<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('events.update', $evento->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>


            <div class="form-group">
                <label for="name">Nombre del Evento:</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($evento->name); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Descripción:</label>
                <textarea class="form-control" id="description" name="description" required><?php echo e($evento->description); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="fecha" class="form-label">Fecha</label>
                <input class="form-control" type="date" id="fecha" name="fecha" rows="3" required value="<?php echo e($evento->fecha); ?>"/>
            </div>


            <div class="mb-3">
                <label for="hora" class="form-label">Hora</label>
                <input class="form-control" type="time" id="hora" name="hora" rows="3" required value="<?php echo e($evento->hora); ?>" />
            </div>


            <button type="submit" class="btn btn-primary">Actualizar Evento</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\M07-PHP\UF3\Laravel_v10\projectUPC\resources\views/events/edit.blade.php ENDPATH**/ ?>