<?php $__env->startSection('content'); ?>

    <div class="text-center">

        <h1>N:M</h1>
































        <div class="container mt-5">
            <h2>Listado de Eventos y Usuarios Inscritos</h2>
            <div class="row">
                <div class="col-12">
                    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mt-3">
                            <div class="card-header">
                                Evento: <?php echo e($evento->name); ?> - Fecha: <?php echo e($evento->fecha); ?>

                            </div>
                            <ul class="list-group list-group-flush">
                                <?php if($evento->usuariosInscritos->isEmpty()): ?>
                                    <li class="list-group-item">No hay usuarios inscritos</li>
                                <?php else: ?>
                                    <?php $contador = 1; ?>

                                    <?php $__currentLoopData = $evento->usuariosInscritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item"><?php echo e($contador); ?>.<?php echo e($usuario->name); ?> - <?php echo e($usuario->email); ?></li>
                                        <?php $contador++; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>










        <div class="container mt-5">
            <h2>Listado de Torneos y Usuarios Inscritos</h2>
            <div class="row">
                <div class="col-12">
                    <?php $__currentLoopData = $torneos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $torneo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mt-3">
                            <div class="card-header">
                                Torneo: <?php echo e($torneo->name); ?> - Fecha: <?php echo e($torneo->fecha); ?>

                            </div>
                            <ul class="list-group list-group-flush">
                                <?php if($torneo->usuariosInscritos->isEmpty()): ?>
                                    <li class="list-group-item">No hay usuarios inscritos</li>
                                <?php else: ?>
                                    <?php $contador = 1; ?>

                                    <?php $__currentLoopData = $torneo->usuariosInscritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item"><?php echo e($contador); ?>.<?php echo e($usuario->name); ?> - <?php echo e($usuario->email); ?></li>
                                        <?php $contador++; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\M07-PHP\UF3\Laravel_v10\projectUPC\resources\views/n_m/nm.blade.php ENDPATH**/ ?>