<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card border-0 shadow">
                    <div class="card-header bg-primary text-white">Gestión de <?php echo e(__('Tournaments')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="text-center mb-4">
                            <h2 class="mb-0">Torneos Destacados</h2>
                            <p>Explora y participa en los próximos torneos</p>
                        </div>

                        <?php if($tournaments->isEmpty()): ?>
                            <div class="alert alert-info">No hay torneos disponibles en este momento.</div>
                        <?php else: ?>
                            <div class="row row-cols-1 row-cols-md-3 g-4">
                                <?php $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $torneo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col">
                                        <div class="card h-100 border-0">
                                            <div class="card-body">
                                                <h5 class="card-title text-primary"><?php echo e($torneo->name); ?></h5>
                                                <p class="card-text"><?php echo e($torneo->description); ?></p>
                                                <p class="card-text">
                                                    <small class="text-muted">Fecha: <?php echo e($torneo->fecha); ?></small> |
                                                    <small class="text-muted">Hora: <?php echo e($torneo->hora); ?></small>
                                                </p>
                                                <p class="card-text"><small class="text-muted">Organizador: <?php echo e($torneo->nombreCreador); ?></small></p>
                                            </div>
                                            <?php if(isset($userType) && $userType == 'guest'): ?>
                                                <form id="apuntar-form-<?php echo e($torneo->id); ?>"
                                                      action="<?php echo e(route('tournaments.apuntar', $torneo->id)); ?>" method="GET">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="submit" class="btn btn-outline-primary" value="Apuntar">
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\M07-PHP\UF3\Laravel_v10\projectUPC\resources\views/tournaments/index.blade.php ENDPATH**/ ?>