<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card border-0 shadow">
                    <div class="card-header bg-primary text-white">Gestión de <?php echo e(__('Events')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="text-center mb-4">
                            <h2 class="mb-0">Eventos Destacados</h2>
                            <p>Descubre los próximos eventos</p>
                        </div>

                        <?php if($eventos->isEmpty()): ?>
                            <div class="alert alert-info">No hay eventos disponibles en este momento.</div>
                        <?php else: ?>
                            <div class="row row-cols-1 row-cols-md-3 g-4">
                                <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col">
                                        <div class="card h-100 border-0">
                                            <div class="card-body">
                                                <h5 class="card-title text-primary"><?php echo e($evento->name); ?></h5>
                                                <p class="card-text"><?php echo e($evento->description); ?></p>
                                                <p class="card-text">
                                                    <small class="text-muted">Fecha: <?php echo e($evento->fecha); ?></small> |
                                                    <small class="text-muted">Hora: <?php echo e($evento->hora); ?></small>
                                                </p>
                                                <p class="card-text"><small
                                                        class="text-muted">Autor: <?php echo e($evento->nombreCreador); ?></small>
                                                </p>
                                            </div>


                                            <?php if(isset($userType) && $userType == 'guest'): ?>
                                                <form id="apuntar-form-<?php echo e($evento->id); ?>"
                                                      action="<?php echo e(route('events.apuntar', $evento->id)); ?>" method="GET">
                                                    <?php echo csrf_field(); ?>
                                                        <input type="submit" class="btn btn-outline-primary" value="Apuntar">
                                                </form>
                                            <?php endif; ?>


                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\M07-PHP\UF3\Laravel_v10\projectUPC\resources\views/events/index.blade.php ENDPATH**/ ?>