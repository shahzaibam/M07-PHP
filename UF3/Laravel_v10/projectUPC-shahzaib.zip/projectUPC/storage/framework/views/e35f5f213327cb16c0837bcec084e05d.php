<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contacto</title>

    <!-- Enlace al CSS -->
    <link href="<?php echo e(asset('css/contact/styles.css')); ?>" rel="stylesheet">
</head>

<body>



<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center">
    <div class="contact-form mt-5">
        <h1 class="text-center">Contacto</h1>
        <form action="#" method="post">
            
            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required>
            </div>

            
            <div class="form-group">
                <label for="correo">Correo electrónico:</label>
                <input type="email" id="correo" name="correo" required>
            </div>

            
            <div class="form-group">
                <label for="mensaje">Mensaje:</label>
                <textarea id="mensaje" name="mensaje" rows="6" required></textarea>
            </div>

            
            <button type="submit" class="submit-btn">Enviar</button>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\M07-PHP\UF3\Laravel_v10\projectUPC\resources\views/contactUs/index.blade.php ENDPATH**/ ?>