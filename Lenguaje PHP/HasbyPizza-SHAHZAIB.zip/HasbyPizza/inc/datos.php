<?php

$menuOptions = [
    "Pepperoni Drink" => "12€",
    "Barbeque Water" => "10€",
    "Special HasbyPizza Complements" => "17€"
];


?>