<?php

include ("./layout-structure.php");

myHeader();

myMenu();
?>
<body>

    <div>
        <h1>home</h1>
    </div>
</body>
</html>